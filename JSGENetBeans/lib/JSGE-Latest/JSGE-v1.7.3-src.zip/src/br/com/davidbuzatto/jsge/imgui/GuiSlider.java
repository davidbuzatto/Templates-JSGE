/*
 * Copyright (C) 2026 Prof. Dr. David Buzatto
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package br.com.davidbuzatto.jsge.imgui;

import br.com.davidbuzatto.jsge.collision.CollisionUtils;
import br.com.davidbuzatto.jsge.core.engine.EngineFrame;
import br.com.davidbuzatto.jsge.geom.Rectangle;
import br.com.davidbuzatto.jsge.math.MathUtils;
import br.com.davidbuzatto.jsge.math.Vector2;
import java.awt.Color;

/**
 * A slider component.
 *
 * @author Prof. Dr. David Buzatto
 */
public class GuiSlider extends GuiComponent {
    
    public static final int HORIZONTAL = 1;
    public static final int VERTICAL = 2;
    private double value;
    private double min;
    private double max;
    
    protected GuiSliderButton sliderButton;
    private int orientation;
    private boolean showTrack;
    
    private boolean mouseWheelEnabled;
    
    private Color trackFillColor;
    
    /**
     * Creates the component.
     *
     * @param x The x coordinate of the upper-left vertex of the rectangle that
     * defines the bounds of the component.
     * @param y The y coordinate of the upper-left vertex of the rectangle that
     * defines the bounds of the component.
     * @param width Width of the rectangle that defines the bounds of the component.
     * @param height Height of the rectangle that defines the bounds of the component.
     * @param value The initial value of the component.
     * @param min The minimum value of the component.
     * @param max The maximum value of the component.
     * @param engine The engine instance used to draw and update the component.
     */
    public GuiSlider( double x, double y, double width, double height, double value, double min, double max, EngineFrame engine ) {
        this( x, y, width, height, value, min, max, HORIZONTAL, engine );
    }

    /**
     * Creates the component.
     *
     * This constructor version depends on the "injectable" configuration of an
     * engine instance.
     * @see br.com.davidbuzatto.jsge.core.engine.EngineFrame#useAsDependencyForIMGUI
     *
     * @param x The x coordinate of the upper-left vertex of the rectangle that
     * defines the bounds of the component.
     * @param y The y coordinate of the upper-left vertex of the rectangle that
     * defines the bounds of the component.
     * @param width Width of the rectangle that defines the bounds of the component.
     * @param height Height of the rectangle that defines the bounds of the component.
     * @param value The initial value of the component.
     * @param min The minimum value of the component.
     * @param max The maximum value of the component.
     */
    public GuiSlider( double x, double y, double width, double height, double value, double min, double max ) {
        this( x, y, width, height, value, min, max, HORIZONTAL );
    }

    /**
     * Creates the component.
     *
     * @param bounds A rectangle that defines the bounds of the component.
     * @param value The initial value of the component.
     * @param min The minimum value of the component.
     * @param max The maximum value of the component.
     * @param engine The engine instance used to draw and update the component.
     */
    public GuiSlider( Rectangle bounds, double value, double min, double max, EngineFrame engine ) {
        this( bounds, value, min, max, HORIZONTAL, engine );
    }

    /**
     * Creates the component.
     *
     * This constructor version depends on the "injectable" configuration of an
     * engine instance.
     * @see br.com.davidbuzatto.jsge.core.engine.EngineFrame#useAsDependencyForIMGUI
     *
     * @param bounds A rectangle that defines the bounds of the component.
     * @param value The initial value of the component.
     * @param min The minimum value of the component.
     * @param max The maximum value of the component.
     */
    public GuiSlider( Rectangle bounds, double value, double min, double max ) {
        this( bounds, value, min, max, HORIZONTAL );
    }

    /**
     * Creates the component.
     *
     * @param x The x coordinate of the upper-left vertex of the rectangle that
     * defines the bounds of the component.
     * @param y The y coordinate of the upper-left vertex of the rectangle that
     * defines the bounds of the component.
     * @param width Width of the rectangle that defines the bounds of the component.
     * @param height Height of the rectangle that defines the bounds of the component.
     * @param value The initial value of the component.
     * @param min The minimum value of the component.
     * @param max The maximum value of the component.
     * @param orientation Whether the slider is horizontal or vertical.
     * @param engine The engine instance used to draw and update the component.
     */
    public GuiSlider( double x, double y, double width, double height, double value, double min, double max, int orientation, EngineFrame engine ) {
        super( x, y, width, height, engine );
        initData( value, min, max, orientation );
        initComponents( engine, SLIDER_RADIUS );
    }

    /**
     * Creates the component.
     *
     * This constructor version depends on the "injectable" configuration of an
     * engine instance.
     * @see br.com.davidbuzatto.jsge.core.engine.EngineFrame#useAsDependencyForIMGUI
     *
     * @param x The x coordinate of the upper-left vertex of the rectangle that
     * defines the bounds of the component.
     * @param y The y coordinate of the upper-left vertex of the rectangle that
     * defines the bounds of the component.
     * @param width Width of the rectangle that defines the bounds of the component.
     * @param height Height of the rectangle that defines the bounds of the component.
     * @param value The initial value of the component.
     * @param min The minimum value of the component.
     * @param max The maximum value of the component.
     * @param orientation Whether the slider is horizontal or vertical.
     */
    public GuiSlider( double x, double y, double width, double height, double value, double min, double max, int orientation ) {
        super( x, y, width, height );
        initData( value, min, max, orientation );
        initComponents( null, SLIDER_RADIUS );
    }

    /**
     * Creates the component.
     *
     * @param bounds A rectangle that defines the bounds of the component.
     * @param value The initial value of the component.
     * @param min The minimum value of the component.
     * @param max The maximum value of the component.
     * @param orientation Whether the slider is horizontal or vertical.
     * @param engine The engine instance used to draw and update the component.
     */
    public GuiSlider( Rectangle bounds, double value, double min, double max, int orientation, EngineFrame engine ) {
        super( bounds, engine );
        initData( value, min, max, orientation );
        initComponents( engine, SLIDER_RADIUS );
    }

    /**
     * Creates the component.
     *
     * This constructor version depends on the "injectable" configuration of an
     * engine instance.
     * @see br.com.davidbuzatto.jsge.core.engine.EngineFrame#useAsDependencyForIMGUI
     *
     * @param bounds A rectangle that defines the bounds of the component.
     * @param value The initial value of the component.
     * @param min The minimum value of the component.
     * @param max The maximum value of the component.
     * @param orientation Whether the slider is horizontal or vertical.
     */
    public GuiSlider( Rectangle bounds, double value, double min, double max, int orientation ) {
        super( bounds );
        initData( value, min, max, orientation );
        initComponents( null, SLIDER_RADIUS );
    }
    
    private void initData( double value, double min, double max, int orientation ) {
        this.value = value;
        this.min = min;
        this.max = max;
        this.orientation = orientation;
        this.showTrack = true;
        this.mouseWheelEnabled = true;
        this.backgroundColor = CONTAINER_BACKGROUND_COLOR;
        this.trackFillColor = MOUSE_DOWN_BACKGROUND_COLOR;
    }
    
    private void initComponents( EngineFrame engine, double sliderRadius ) {
        if ( engine == null ) {
            if ( orientation == HORIZONTAL ) {
                sliderButton = new GuiSliderButton( bounds.x, bounds.y + bounds.height / 2 - sliderRadius, sliderRadius * 2, sliderRadius * 2, sliderRadius, true );
            } else {
                sliderButton = new GuiSliderButton( bounds.x + bounds.width / 2 - sliderRadius, bounds.y, sliderRadius * 2, sliderRadius * 2, sliderRadius, false );
            }
        } else {
            if ( orientation == HORIZONTAL ) {
                sliderButton = new GuiSliderButton( bounds.x, bounds.y + bounds.height / 2 - sliderRadius, sliderRadius * 2, sliderRadius * 2, sliderRadius, true, engine );
            } else {
                sliderButton = new GuiSliderButton( bounds.x + bounds.width / 2 - sliderRadius, bounds.y, sliderRadius * 2, sliderRadius * 2, sliderRadius, false, engine );
            }
        }
        updateSliderButtonPosition();
    }
    
    @Override
    public void update( double delta ) {
        
        super.update( delta );
        
        if ( visible && enabled ) {
            
            Vector2 mousePos = engine.getMousePositionPoint();
            sliderButton.update( delta, bounds );
            
            if ( mouseWheelEnabled ) {
                if ( mouseState == GuiComponentMouseState.MOUSE_OVER ) {
                    double mouseWheelMove = engine.getMouseWheelMove() * ( ( max - min ) / 10 );
                    if ( min <= max ) {
                        setValue( getValue() + mouseWheelMove );
                    } else {
                        setValue( getValue() - mouseWheelMove );
                    }
                }
            }
            
            if ( mouseState == GuiComponentMouseState.MOUSE_DOWN && sliderButton.mouseState == GuiComponentMouseState.MOUSE_OUT ) {
                if ( orientation == VERTICAL ) {
                    sliderButton.bounds.y = mousePos.y - SLIDER_RADIUS;
                } else {
                    sliderButton.bounds.x = mousePos.x - SLIDER_RADIUS;
                }
                sliderButton.update( delta, bounds );
            }
            
            if ( orientation == VERTICAL ) {
                
                double maxSliderY = bounds.y + sliderButton.radius;
                double minSliderY = bounds.y + bounds.height - sliderButton.radius;
                double sliderY = sliderButton.bounds.y + sliderButton.radius;
                double percentage = MathUtils.inverseLerp( minSliderY, maxSliderY, sliderY );

                value = MathUtils.lerp( min, max, percentage );
                
            } else {
                
                double minSliderX = bounds.x + sliderButton.radius;
                double maxSliderX = bounds.x + bounds.width - sliderButton.radius;
                double sliderX = sliderButton.bounds.x + sliderButton.radius;
                double percentage = MathUtils.inverseLerp( minSliderX, maxSliderX, sliderX );

                value = MathUtils.lerp( min, max, percentage );
            
            }
            
        }
        
    }
    
    @Override
    public void draw() {
        
        if ( visible ) {
            
            engine.setStrokeLineWidth( LINE_WIDTH );

            if ( enabled ) {
                switch ( mouseState ) {
                    case MOUSE_OVER:
                        drawSlider( CONTAINER_BACKGROUND_COLOR, MOUSE_OVER_BORDER_COLOR, MOUSE_DOWN_BACKGROUND_COLOR, 4 );
                        break;
                    case MOUSE_DOWN:
                        drawSlider( CONTAINER_BACKGROUND_COLOR, MOUSE_DOWN_BORDER_COLOR, MOUSE_DOWN_BACKGROUND_COLOR, 4 );
                        break;
                    default:
                        drawSlider( backgroundColor, borderColor, trackFillColor, 4 );
                        break;
                }
            } else {
                drawSlider( DISABLED_CONTAINER_BACKGROUND_COLOR, DISABLED_BORDER_COLOR, MOUSE_DOWN_BACKGROUND_COLOR, 4 );
            }
            
            drawBounds();
            
        }
        
    }
    
    private void drawSlider( Color backgroundColor, Color borderColor, Color valueColor, double sliderBarSize ) {
        if ( showTrack ) {
            if ( orientation == VERTICAL ) {
                engine.fillRectangle( bounds.x + bounds.width / 2 - sliderBarSize / 2, bounds.y, sliderBarSize, bounds.height, backgroundColor );
                if ( enabled ) {
                    engine.fillRectangle( bounds.x + bounds.width / 2 - sliderBarSize / 2, sliderButton.bounds.y, sliderBarSize, bounds.y + bounds.height - sliderButton.bounds.y, valueColor );
                }
                engine.drawRectangle( bounds.x + bounds.width / 2 - sliderBarSize / 2, bounds.y, sliderBarSize, bounds.height, borderColor );
            } else { // horizontal
                engine.fillRectangle( bounds.x, bounds.y + bounds.height / 2 - sliderBarSize / 2, bounds.width, sliderBarSize, backgroundColor );
                if ( enabled ) {
                    engine.fillRectangle( bounds.x, bounds.y + bounds.height / 2 - sliderBarSize / 2, sliderButton.bounds.x - bounds.x, sliderBarSize, valueColor );
                }
                engine.drawRectangle( bounds.x, bounds.y + bounds.height / 2 - sliderBarSize / 2, bounds.width, sliderBarSize, borderColor );
            }
        }
        sliderButton.draw();
    }
    
    private void updateSliderButtonPosition() {
        
        if ( orientation == VERTICAL ) {
            
            double maxSliderY = bounds.y + sliderButton.radius;
            double minSliderY = bounds.y + bounds.height - sliderButton.radius;
            double percentage = MathUtils.inverseLerp( min, max, value );

            double sliderY = MathUtils.lerp( minSliderY, maxSliderY, percentage );
            sliderButton.bounds.y = sliderY - sliderButton.radius;
            
        } else {
            
            double minSliderX = bounds.x + sliderButton.radius;
            double maxSliderX = bounds.x + bounds.width - sliderButton.radius;
            double percentage = MathUtils.inverseLerp( min, max, value );

            double sliderX = MathUtils.lerp( minSliderX, maxSliderX, percentage );
            sliderButton.bounds.x = sliderX - sliderButton.radius;
            
        }
        
    }

    @Override
    public void setEnabled( boolean enabled ) {
        super.setEnabled( enabled );
        sliderButton.setEnabled( enabled );
    }

    @Override
    public void setVisible( boolean visible ) {
        super.setVisible( visible );
        sliderButton.setVisible( visible );
    }
    
    /**
     * Gets the current value of the component.
     *
     * @return The current value.
     */
    public double getValue() {
        return value;
    }

    /**
     * Sets the value of the component.
     *
     * @param value The value of the component.
     */
    public void setValue( double value ) {
        if ( min <= max ) {
            this.value = MathUtils.clamp( value, min, max );
        } else {
            this.value = MathUtils.clamp( value, max, min );
        }
        updateSliderButtonPosition();
    }

    /**
     * Returns the minimum value of the component.
     *
     * @return The minimum value.
     */
    public double getMin() {
        return min;
    }

    /**
     * Sets the minimum value of the component.
     *
     * @param min The minimum value of the component.
     */
    public void setMin( double min ) {
        this.min = min;
    }

    /**
     * Returns the maximum value of the component.
     *
     * @return The maximum value.
     */
    public double getMax() {
        return max;
    }

    /**
     * Sets the maximum value of the component.
     *
     * @param max The maximum value of the component.
     */
    public void setMax( double max ) {
        this.max = max;
    }

    /**
     * Returns whether the component track is visible.
     *
     * @return True if it is visible, false otherwise.
     */
    public boolean isShowTrack() {
        return showTrack;
    }

    /**
     * Sets the visibility of the component track.
     *
     * @param showTrack True to show the track, false to hide it.
     */
    public void setShowTrack( boolean showTrack ) {
        this.showTrack = showTrack;
    }

    /**
     * Returns whether the component responds to mouse wheel scrolling.
     *
     * @return True if it does, false otherwise.
     */
    public boolean isMouseWheelEnabled() {
        return mouseWheelEnabled;
    }

    /**
     * Sets whether the component should respond to mouse wheel scrolling.
     *
     * @param mouseWheelEnabled True to respond, false to not respond.
     */
    public void setMouseWheelEnabled( boolean mouseWheelEnabled ) {
        this.mouseWheelEnabled = mouseWheelEnabled;
    }

    /**
     * Gets the fill color of the track.
     *
     * @return The fill color of the track.
     */
    public Color getTrackFillColor() {
        return trackFillColor;
    }

    /**
     * Sets the fill color of the track.
     *
     * @param trackFillColor The fill color of the track.
     */
    public void setTrackFillColor( Color trackFillColor ) {
        this.trackFillColor = trackFillColor;
    }
    
    @Override
    public void move( double xAmount, double yAmount ) {
        bounds.x += xAmount;
        bounds.y += yAmount;
        sliderButton.bounds.x += xAmount;
        sliderButton.bounds.y += yAmount;
    }
    
    protected class GuiSliderButton extends GuiButton {
        
        private final double radius;
        private boolean dragging;
        private Vector2 prevMousePos;
        private final boolean moveHorizontally;
        
        public GuiSliderButton( double x, double y, double width, double height, double radius, boolean moveHorizontally, EngineFrame engine ) {
            super( x, y, width, height, "", engine );
            this.radius = radius;
            this.moveHorizontally = moveHorizontally;
        }
        
        public GuiSliderButton( double x, double y, double width, double height, double radius, boolean moveHorizontally ) {
            super( x, y, width, height, "" );
            this.radius = radius;
            this.moveHorizontally = moveHorizontally;
        }

        public void update( double delta, Rectangle containerBounds ) {

            if ( visible && enabled ) {

                Vector2 mousePos = engine.getMousePositionPoint();

                if ( CollisionUtils.checkCollisionPointRectangle( mousePos, bounds ) ) {
                    mouseState = GuiComponentMouseState.MOUSE_OVER;
                    if ( engine.isMouseButtonPressed( EngineFrame.MOUSE_BUTTON_LEFT ) ) {
                        mouseState = GuiComponentMouseState.MOUSE_PRESSED;
                    } else if ( engine.isMouseButtonDown( EngineFrame.MOUSE_BUTTON_LEFT ) ) {
                        mouseState = GuiComponentMouseState.MOUSE_DOWN;
                        dragging = true;
                    }
                } else {
                    mouseState = GuiComponentMouseState.MOUSE_OUT;
                }
                
                if ( engine.isMouseButtonUp( EngineFrame.MOUSE_BUTTON_LEFT ) ) {
                    dragging = false;
                }
                
                if ( dragging ) {
                    
                    mouseState = GuiComponentMouseState.MOUSE_DOWN;
                    
                    if ( moveHorizontally ) {
                        bounds.x += mousePos.x - prevMousePos.x;
                        if ( bounds.x + radius * 2 > containerBounds.x + containerBounds.width ) {
                            bounds.x = containerBounds.x + containerBounds.width - radius * 2;
                        } else if ( bounds.x < containerBounds.x ) {
                            bounds.x = containerBounds.x;
                        }
                    } else {
                        bounds.y += mousePos.y - prevMousePos.y;
                        if ( bounds.y + radius * 2 > containerBounds.y + containerBounds.height ) {
                            bounds.y = containerBounds.y + containerBounds.height - radius * 2;
                        } else if ( bounds.y < containerBounds.y ) {
                            bounds.y = containerBounds.y;
                        }
                    }
                }
                
                prevMousePos = mousePos;

            } else {
                mouseState = GuiComponentMouseState.MOUSE_OUT;
            }

        }
    
        @Override
        public void draw() {
            
            if ( visible ) {

                engine.setStrokeLineWidth( LINE_WIDTH );

                if ( enabled ) {

                    switch ( mouseState ) {
                        case MOUSE_OUT:
                            drawSliderButton( backgroundColor, borderColor );
                            break;
                        case MOUSE_OVER:
                            drawSliderButton( MOUSE_OVER_BACKGROUND_COLOR, MOUSE_OVER_BORDER_COLOR );
                            break;
                        case MOUSE_PRESSED:
                            drawSliderButton( MOUSE_DOWN_BACKGROUND_COLOR, MOUSE_DOWN_BORDER_COLOR );
                            break;
                        case MOUSE_DOWN:
                            drawSliderButton( MOUSE_DOWN_BACKGROUND_COLOR, MOUSE_DOWN_BORDER_COLOR );
                            break;
                    }

                } else {
                    drawSliderButton( DISABLED_BACKGROUND_COLOR, DISABLED_BORDER_COLOR );
                }
                
                drawBounds();

            }
            
        }
        
        private void drawSliderButton( Color backgroundColor, Color borderColor ) {
            engine.fillCircle( bounds.x + bounds.width / 2, bounds.y + bounds.height / 2, radius, backgroundColor );
            engine.drawCircle( bounds.x + bounds.width / 2, bounds.y + bounds.height / 2, radius, borderColor );
        }
        
    }
    
    @Override
    public void apply( GuiTheme theme ) {
        super.apply( theme );
        setBackgroundColor( theme.containerBackgroundColor );
        setTrackFillColor( theme.mouseOverBackgroundColor );
        sliderButton.apply( theme );
    }
    
}
